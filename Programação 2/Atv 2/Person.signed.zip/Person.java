
/********************************************************
 *                                                       
 * PROBLEM:                                            
 *                                                      
 * Consider the design of the class Person and
 * ensures that the design overrides and implement
 * the equals method properly for object comparison.
 *                                                       
 * @author Henrique Rebelo                              
 ********************************************************/
public class Person {

	private String firstName;
	private String lastName;
	private int age;
	private String cpf;

   public Person(String firstName, String lastName, int age, String cpf) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.cpf = cpf;
	}

	public boolean equals(Object obj) {
      if (this == obj)	return true;
		if (obj == null)	return false;
		if (obj.getClass() != getClass())	return false;
		Person other = (Person) obj;
		return (firstName.equals(other.firstName)) && (lastName.equals(other.lastName))
				&& (age == other.age) && (cpf.equals(other.cpf));
	}
}
